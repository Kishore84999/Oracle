select * from 
(select * from (
select distinct
paam.Assignment_Number,
to_char(psa.start_date,'DD/MM/YYYY') start_date,
to_char(psa.end_date,'DD/MM/YYYY') end_date,
zsst.schedule_name,
PASTVL.USER_STATUS AS ASSIGNMENT_STATUS,
HRLE.NAME AS LegalEmployer,
haot.name BUSINESS_UNIT_ID,
ppnf.display_name as Name,
papf.PERSON_NUMBER person_number,
psa.resource_type resource_type,
case when paam.action_code = 'END_ASG' then 
to_char((paam.effective_start_date - 1),'DD/MM/YYYY') else '' end ASG_END,
psa.primary_flag

from
per_schedule_assignments psa,
ZMM_SR_SCHEDULES_TL zsst,
per_all_assignments_m paam,
PER_ASSIGNMENT_STATUS_TYPES_VL PASTVL,
HR_LEGAL_ENTITIES HRLE,
HR_ALL_ORGANIZATION_UNITS_F hao,
HR_ORGANIZATION_UNITS_F_TL haot,
PER_PERSON_SECURED_LIST_V papf,
per_person_names_f ppnf

where
psa.schedule_id=zsst.schedule_id and
paam.LEGAL_ENTITY_ID = psa.resource_id and
PAAM.ASSIGNMENT_STATUS_TYPE_ID = PASTVL.ASSIGNMENT_STATUS_TYPE_ID AND
HRLE.ORGANIZATION_ID(+)=PAAM.LEGAL_ENTITY_ID AND
--hou.organization_id = paam.organization_id AND
PAPF.PERSON_ID =PAAM.PERSON_ID AND
PPNF.PERSON_ID = PAAM.PERSON_ID AND
PPNF.NAME_TYPE (+)= 'GLOBAL' AND
psa.resource_type='LEGALEMP'
 -- and
-- paam.ASSIGNMENT_STATUS_TYPE = 'ACTIVE' 
AND
hao.ORGANIZATION_ID = haot.ORGANIZATION_ID
AND hao.EFFECTIVE_START_DATE = haot.EFFECTIVE_START_DATE
AND hao.EFFECTIVE_END_DATE = haot.EFFECTIVE_END_DATE
AND TRUNC(SYSDATE) BETWEEN trunc(hao.EFFECTIVE_START_DATE) AND trunc(hao.EFFECTIVE_END_DATE)
AND haot.LANGUAGE='US'
AND paam.ASSIGNMENT_TYPE = 'E'
and paam.BUSINESS_UNIT_ID=hao.organization_id and 
TRUNC(SYSDATE) BETWEEN PPNF.EFFECTIVE_START_DATE AND PPNF.EFFECTIVE_END_DATE AND
TRUNC(SYSDATE) BETWEEN HRLE.EFFECTIVE_START_DATE (+)AND HRLE.EFFECTIVE_END_DATE(+) AND
trunc(sysdate) between paam.effective_start_date and paam.effective_end_date AND
TRUNC(SYSDATE) BETWEEN PAPF.EFFECTIVE_START_DATE AND PAPF.EFFECTIVE_END_DATE
and  person_number = nvl(:P_NUM,person_number )




union  all

select distinct
paam.Assignment_Number,
to_char(psa.start_date,'DD/MM/YYYY') start_date,
to_char(psa.end_date,'DD/MM/YYYY') end_date,
zsst.schedule_name,
PASTVL.USER_STATUS AS ASSIGNMENT_STATUS,
HRLE.NAME AS LegalEmployer,
haot.name BUSINESS_UNIT_ID,
ppnf.display_name as Name,
papf.PERSON_NUMBER person_number,
psa.resource_type resource_type,
case when paam.action_code = 'END_ASG' then 
to_char((paam.effective_start_date - 1),'DD/MM/YYYY') else '' end ASG_END,
psa.primary_flag

from
per_schedule_assignments psa,
ZMM_SR_SCHEDULES_TL zsst,
per_all_assignments_m paam,
PER_ASSIGNMENT_STATUS_TYPES_VL PASTVL,
HR_LEGAL_ENTITIES HRLE,
HR_ALL_ORGANIZATION_UNITS_F hao,
HR_ORGANIZATION_UNITS_F_TL haot,
PER_PERSON_SECURED_LIST_V papf,
per_person_names_f ppnf

where
psa.schedule_id=zsst.schedule_id and
paam.assignment_id = psa.resource_id and
PAAM.ASSIGNMENT_STATUS_TYPE_ID = PASTVL.ASSIGNMENT_STATUS_TYPE_ID AND
HRLE.ORGANIZATION_ID=PAAM.LEGAL_ENTITY_ID AND
--hou.organization_id = paam.organization_id AND
PAPF.PERSON_ID =PAAM.PERSON_ID AND
PPNF.PERSON_ID = PAAM.PERSON_ID AND
PPNF.NAME_TYPE (+)= 'GLOBAL'
-- AND
-- psa.resource_type='LEGALEMP' 
-- and
-- paam.ASSIGNMENT_STATUS_TYPE = 'ACTIVE'
 AND
hao.ORGANIZATION_ID = haot.ORGANIZATION_ID
AND hao.EFFECTIVE_START_DATE = haot.EFFECTIVE_START_DATE
AND hao.EFFECTIVE_END_DATE = haot.EFFECTIVE_END_DATE
AND TRUNC(SYSDATE) BETWEEN hao.EFFECTIVE_START_DATE AND hao.EFFECTIVE_END_DATE
AND haot.LANGUAGE='US'
AND paam.ASSIGNMENT_TYPE = 'E'
and paam.BUSINESS_UNIT_ID=hao.organization_id and 
TRUNC(SYSDATE) BETWEEN PPNF.EFFECTIVE_START_DATE AND PPNF.EFFECTIVE_END_DATE AND
TRUNC(SYSDATE) BETWEEN HRLE.EFFECTIVE_START_DATE (+)AND HRLE.EFFECTIVE_END_DATE(+) AND
trunc(sysdate) between paam.effective_start_date and paam.effective_end_date AND
TRUNC(SYSDATE) BETWEEN PAPF.EFFECTIVE_START_DATE AND PAPF.EFFECTIVE_END_DATE
and  person_number = nvl(:P_NUM,person_number )

)
where (resource_type!='LEGALEMP' )



union 
select * from (
select distinct
paam.Assignment_Number,
to_char(psa.start_date,'DD/MM/YYYY') start_date,
to_char(psa.end_date,'DD/MM/YYYY') end_date,
zsst.schedule_name,
PASTVL.USER_STATUS AS ASSIGNMENT_STATUS,
HRLE.NAME AS LegalEmployer,
haot.name BUSINESS_UNIT_ID,
ppnf.display_name as Name,
papf.PERSON_NUMBER person_number,
psa.resource_type resource_type,
case when paam.action_code = 'END_ASG' then 
to_char((paam.effective_start_date - 1),'DD/MM/YYYY') else '' end ASG_END,
psa.primary_flag

from
per_schedule_assignments psa,
ZMM_SR_SCHEDULES_TL zsst,
per_all_assignments_m paam,
PER_ASSIGNMENT_STATUS_TYPES_VL PASTVL,
HR_LEGAL_ENTITIES HRLE,
HR_ALL_ORGANIZATION_UNITS_F hao,
HR_ORGANIZATION_UNITS_F_TL haot,
PER_PERSON_SECURED_LIST_V papf,
per_person_names_f ppnf

where
psa.schedule_id=zsst.schedule_id and

paam.LEGAL_ENTITY_ID = psa.resource_id and
PAAM.ASSIGNMENT_STATUS_TYPE_ID = PASTVL.ASSIGNMENT_STATUS_TYPE_ID AND
HRLE.ORGANIZATION_ID(+)=PAAM.LEGAL_ENTITY_ID AND
--hou.organization_id = paam.organization_id AND
PAPF.PERSON_ID =PAAM.PERSON_ID AND
PPNF.PERSON_ID = PAAM.PERSON_ID AND
PPNF.NAME_TYPE (+)= 'GLOBAL' AND
psa.resource_type='LEGALEMP'
 -- and
-- paam.ASSIGNMENT_STATUS_TYPE = 'ACTIVE' 
AND
hao.ORGANIZATION_ID = haot.ORGANIZATION_ID
AND hao.EFFECTIVE_START_DATE = haot.EFFECTIVE_START_DATE
AND hao.EFFECTIVE_END_DATE = haot.EFFECTIVE_END_DATE
AND TRUNC(SYSDATE) BETWEEN trunc(hao.EFFECTIVE_START_DATE) AND trunc(hao.EFFECTIVE_END_DATE)
AND haot.LANGUAGE='US'
AND paam.ASSIGNMENT_TYPE = 'E'
and paam.BUSINESS_UNIT_ID=hao.organization_id and 
TRUNC(SYSDATE) BETWEEN PPNF.EFFECTIVE_START_DATE AND PPNF.EFFECTIVE_END_DATE AND
TRUNC(SYSDATE) BETWEEN HRLE.EFFECTIVE_START_DATE (+)AND HRLE.EFFECTIVE_END_DATE(+) AND
trunc(sysdate) between paam.effective_start_date and paam.effective_end_date AND
TRUNC(SYSDATE) BETWEEN PAPF.EFFECTIVE_START_DATE AND PAPF.EFFECTIVE_END_DATE
and  person_number = nvl(:P_NUM,person_number )
AND psa.primary_flag='Y'
--AND papf.person_number = '409834' 
AND papf.person_number Not in (
select distinct

papf.PERSON_NUMBER

from
per_schedule_assignments psa,
ZMM_SR_SCHEDULES_TL zsst,
per_all_assignments_m paam,
PER_ASSIGNMENT_STATUS_TYPES_VL PASTVL,
HR_LEGAL_ENTITIES HRLE,
HR_ALL_ORGANIZATION_UNITS_F hao,
HR_ORGANIZATION_UNITS_F_TL haot,
PER_PERSON_SECURED_LIST_V papf,
per_person_names_f ppnf

where
psa.schedule_id=zsst.schedule_id and
paam.assignment_id = psa.resource_id and
PAAM.ASSIGNMENT_STATUS_TYPE_ID = PASTVL.ASSIGNMENT_STATUS_TYPE_ID AND
HRLE.ORGANIZATION_ID=PAAM.LEGAL_ENTITY_ID AND
--hou.organization_id = paam.organization_id AND
PAPF.PERSON_ID =PAAM.PERSON_ID AND
PPNF.PERSON_ID = PAAM.PERSON_ID AND
PPNF.NAME_TYPE (+)= 'GLOBAL'
-- AND
-- psa.resource_type='LEGALEMP' 
-- and
-- paam.ASSIGNMENT_STATUS_TYPE = 'ACTIVE'
 AND
hao.ORGANIZATION_ID = haot.ORGANIZATION_ID
AND hao.EFFECTIVE_START_DATE = haot.EFFECTIVE_START_DATE
AND hao.EFFECTIVE_END_DATE = haot.EFFECTIVE_END_DATE
AND TRUNC(SYSDATE) BETWEEN hao.EFFECTIVE_START_DATE AND hao.EFFECTIVE_END_DATE
AND haot.LANGUAGE='US'
AND paam.ASSIGNMENT_TYPE = 'E'
and paam.BUSINESS_UNIT_ID=hao.organization_id and 
TRUNC(SYSDATE) BETWEEN PPNF.EFFECTIVE_START_DATE AND PPNF.EFFECTIVE_END_DATE AND
TRUNC(SYSDATE) BETWEEN HRLE.EFFECTIVE_START_DATE (+)AND HRLE.EFFECTIVE_END_DATE(+) AND
trunc(sysdate) between paam.effective_start_date and paam.effective_end_date AND
TRUNC(SYSDATE) BETWEEN PAPF.EFFECTIVE_START_DATE AND PAPF.EFFECTIVE_END_DATE
AND psa.primary_flag='Y'

--AND papf.person_number = '409834' 
)
)
)
order by 
legalemployer,BUSINESS_UNIT_ID,person_number,
Assignment_Number