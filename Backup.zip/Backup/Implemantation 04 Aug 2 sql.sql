/****************************************************************************************************
Date                     Developer         Version               Description    
14-jun-2020            Rajasekhar Kolli      1.0              PCC Letters Report
 ****************************************************************************************************/

SELECT Distinct
    papf.person_number employee_number,
    ppnf.first_name,
    ppnf.last_name,  
    INITCAP(ppnf.title) title,  
    ( ppnf.last_name
    || ', '
    || ppnf.first_name ) full_name,
    paaf.assignment_number assignment_number,
	
--paaf.assignment_id,
    addr_h.postal_code,
    hap.name position_name,
    pg.name Current_Grade_name,
    pgs.name spinal_point,
	CSTEP.ceiling_step,
    pj.name job_name,
    --paaf.normal_hours normal_hours,
    bu_unit.name Business_unit,
    --round(pawmf.value,2) fte,
	
	(case when psdf.seniority_date is null then ppos.date_start 
	else psdf.seniority_date end) as seniority_date,
	
to_char(round(to_char((paaf.normal_hours) /( select pucif.value
                from
                    ff_user_column_instances_f pucif,
                    ff_user_rows_f pur,
                    ff_user_columns puc,
                    ff_user_tables put1
                where
                    put1.user_table_id = puc.user_table_id
                    and   put1.user_table_id = pur.user_table_id
                    and   pucif.user_row_id = pur.user_row_id
                    and   pucif.user_column_id = puc.user_column_id
                    and   upper(trim(put1.base_user_table_name) ) = upper(trim('PCC_CONTRACT_TYPES_UDT') )
                    and   upper(trim(puc.base_user_column_name) ) = upper(trim('Standard_Working_Hours'))
                    and   trunc(sysdate) between trunc(nvl(pucif.effective_start_date(+),sysdate) ) and trunc(nvl(pucif.effective_end_date(+),sysdate) )
                    and   trunc(sysdate) between trunc(nvl(pur.effective_start_date(+),sysdate) ) and trunc(nvl(pur.effective_end_date(+),sysdate) )
                    and   upper(trim(pur.row_low_range_or_name) ) = upper(trim(paaf.ass_attribute1) ))
),2)) fte,

to_char(round(to_char(((paaf.normal_hours) /( select pucif.value
                from
                    ff_user_column_instances_f pucif,
                    ff_user_rows_f pur,
                    ff_user_columns puc,
                    ff_user_tables put1
                where
                    put1.user_table_id = puc.user_table_id
                    and   put1.user_table_id = pur.user_table_id
                    and   pucif.user_row_id = pur.user_row_id
                    and   pucif.user_column_id = puc.user_column_id
                    and   upper(trim(put1.base_user_table_name) ) = upper(trim('PCC_CONTRACT_TYPES_UDT') )
                    and   upper(trim(puc.base_user_column_name) ) = upper(trim('Standard_Working_Hours'))
                    and   trunc(sysdate) between trunc(nvl(pucif.effective_start_date(+),sysdate) ) and trunc(nvl(pucif.effective_end_date(+),sysdate) )
                    and   trunc(sysdate) between trunc(nvl(pur.effective_start_date(+),sysdate) ) and trunc(nvl(pur.effective_end_date(+),sysdate) )
                    and   upper(trim(pur.row_low_range_or_name) ) = upper(trim(paaf.ass_attribute1) ))
)*
(
        SELECT Sal.ANNUAL_FT_SALARY
            --sal.salary_amount
        FROM
            cmp_salary sal
        WHERE
            sal.assignment_id = paaf.assignment_id
            AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(sal.date_from,SYSDATE) AND nvl(sal.date_to,SYSDATE)
    )),2)) FTE_Annual_Salary,

to_char(round(

to_Char((((paaf.normal_hours) / ( select pucif.value
                from
                    ff_user_column_instances_f pucif,
                    ff_user_rows_f pur,
                    ff_user_columns puc,
                    ff_user_tables put1
                where
                    put1.user_table_id = puc.user_table_id
                    and   put1.user_table_id = pur.user_table_id
                    and   pucif.user_row_id = pur.user_row_id
                    and   pucif.user_column_id = puc.user_column_id
                    and   upper(trim(put1.base_user_table_name) ) = upper(trim('PCC_CONTRACT_TYPES_UDT') )
                    and   upper(trim(puc.base_user_column_name) ) = upper(trim('Standard_Working_Hours') )
                    and   trunc(sysdate) between trunc(nvl(pucif.effective_start_date(+),sysdate) ) and trunc(nvl(pucif.effective_end_date(+),sysdate) )
                    and   trunc(sysdate) between trunc(nvl(pur.effective_start_date(+),sysdate) ) and trunc(nvl(pur.effective_end_date(+),sysdate) )
                    and   upper(trim(pur.row_low_range_or_name) ) = upper(trim(paaf.ass_attribute1) ))
) * (
      ( select pucif.value
                from
                    ff_user_column_instances_f pucif,
                    ff_user_rows_f pur,
                    ff_user_columns puc,
                    ff_user_tables put1
                where
                    put1.user_table_id = puc.user_table_id
                    and   put1.user_table_id = pur.user_table_id
                    and   pucif.user_row_id = pur.user_row_id
                    and   pucif.user_column_id = puc.user_column_id
                    and   upper(trim(put1.base_user_table_name) ) = upper(trim('PCC_CONTRACT_TYPES_UDT') )
                    and   upper(trim(puc.base_user_column_name) ) = upper(trim('TTO_Weeks') )
                    and   trunc(sysdate) between trunc(nvl(pucif.effective_start_date(+),sysdate) ) and trunc(nvl(pucif.effective_end_date(+),sysdate) )
                    and   trunc(sysdate) between trunc(nvl(pur.effective_start_date(+),sysdate) ) and trunc(nvl(pur.effective_end_date(+),sysdate) )
                    and   upper(trim(pur.row_low_range_or_name) ) = upper(trim(paaf.ass_attribute1) ))
 / ( select pucif.value
                from
                    ff_user_column_instances_f pucif,
                    ff_user_rows_f pur,
                    ff_user_columns puc,
                    ff_user_tables put1
                where
                    put1.user_table_id = puc.user_table_id
                    and   put1.user_table_id = pur.user_table_id
                    and   pucif.user_row_id = pur.user_row_id
                    and   pucif.user_column_id = puc.user_column_id
                    and   upper(trim(put1.base_user_table_name) ) = upper(trim('PCC_CONTRACT_TYPES_UDT') )
                    and   upper(trim(puc.base_user_column_name) ) = upper(trim('Standard_Week') )
                    and   trunc(sysdate) between trunc(nvl(pucif.effective_start_date(+),sysdate) ) and trunc(nvl(pucif.effective_end_date(+),sysdate) )
                    and   trunc(sysdate) between trunc(nvl(pur.effective_start_date(+),sysdate) ) and trunc(nvl(pur.effective_end_date(+),sysdate) )
                    and   upper(trim(pur.row_low_range_or_name) ) = upper(trim(paaf.ass_attribute1) ))
)
)
*
(
SELECT Sal.ANNUAL_FT_SALARY
--sal.salary_amount
FROM
cmp_salary sal
WHERE
sal.assignment_id = paaf.assignment_id
AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(sal.date_from,SYSDATE) AND nvl(sal.date_to,SYSDATE)
)
),2)) TTO_Salary,

    (
        SELECT
            MAX(fl.meaning)
        FROM
            fnd_lookup_values_tl fl
        WHERE
            fl.lookup_type = 'PER_ETHNICITY'
            AND   fl.lookup_code (+) = pe.ethnicity
            AND   fl.language = userenv('LANG')
    ) ethnic_origin,
    (
        SELECT
            MAX(fl.meaning)
        FROM
            fnd_lookup_values_tl fl
        WHERE
            fl.lookup_type = 'PER_RELIGION'
            AND   fl.lookup_code (+) = pr.religion
            AND   fl.language = userenv('LANG')
    ) religion,
    DECODE(pplf.sex,'M','Male','F','Female',pplf.sex) gender,
    (
        SELECT
            MAX(fl.meaning)
        FROM
            hcm_lookups fl
        WHERE
            fl.lookup_type = 'EMP_CAT'
            AND   upper(TRIM(fl.lookup_code) ) = upper(TRIM(paaf.employment_category) )
    ) assignment_category,
    TO_CHAR(ppos.actual_termination_date,'DD-MM-YYYY') leaving_date,
    TO_CHAR(ppos.date_start,'DD-MM-YYYY') hire_date,
    (
        SELECT Sal.ANNUAL_FT_SALARY
            --sal.salary_amount
        FROM
            cmp_salary sal
        WHERE
            sal.assignment_id = paaf.assignment_id
            AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(sal.date_from,SYSDATE) AND nvl(sal.date_to,SYSDATE)
    ) salary_amount1,

(
select TO_CHAR(min (paaf1.EFFECTIVE_START_DATE),'DD-MM-YYYY')
    from
       per_all_assignments_f paaf1
    where paaf1.assignment_id = paaf.assignment_id
) as asg_start_date,

( case when (TO_CHAR(ppos.date_start,'DD-MM-YYYY'))= (select TO_CHAR(min (paaf1.EFFECTIVE_START_DATE),'DD-MM-YYYY')
															from
															per_all_assignments_f paaf1
															where paaf1.assignment_id = paaf.assignment_id
														) 
		then 'Y'
		else 'N'
end )as hire_asg_date,

(
select (case when to_char(min(paaf2.effective_start_date),'mm') IN('10','11','12','01','02','03') and to_char(min(paaf2.effective_start_date),'mm-dd') not in ('10-01')
then 'Y'
else 'N' end) FLAG from per_all_assignments_f paaf2 where paaf2.assignment_id = paaf.assignment_id) as ASSIGNMENT_COMMENCEMENT_FLAG,

(select  hap1.name 
   from 
    per_all_assignments_f paaf1,
	hr_all_positions hap1 
 where 
     hap1.position_id=paaf1.position_id
	 AND ROWNUM <2
	 AND paaf1.person_id=paaf.person_id
	 AND paaf1.effective_end_date=(paaf.effective_start_date)-1)
     	 as old_position,
		 
(select  PLDF1.location_name 
   from 
    per_all_assignments_f paaf1,
	PER_LOCATION_DETAILS_F_VL PLDF1 
 where 
     PLDF1.LOCATION_ID(+)=paaf1.location_id
	 AND ROWNUM <2
	 AND paaf1.person_id=paaf.person_id
	 AND paaf1.effective_end_date=(paaf.effective_start_date)-1)
     	 as old_location,


/*(
select DISTINCT
ppnf1.display_name
from
per_person_names_f ppnf1
where
ppnf1.person_id = papf.person_id
and trunc(sysdate)between ppnf1.effective_start_date and effective_end_date
and ppnf1.NAME_TYPE = 'GLOBAL'
AND ROWNUM =1
) AS contact_name,*/


    paaf.ass_attribute1 contract_type,
	(case when paaf.ass_attribute1 like ('%TTO%') then 'Y'
		 else 'N' end) TTO_SALARY_FLAG,
		 
	pptt.user_person_type PERSON_TYPE,	 
   -- TO_CHAR(paaf.effective_start_date,'DD-Mon-YYYY','nls_date_language = ENGLISH') asg_start_date,
    TO_CHAR(paaf.effective_end_date,'DD-MM-YYYY') asg_end_date,
    TO_CHAR(per.date_of_birth,'DD-MM-YYYY') date_of_birth,
    paaf.primary_flag primary_flag,
    parb.action_reason leave_reason,
    pni.national_identifier_number national_identifier,
    TO_CHAR(ppos.adjusted_svc_date,'DD-MM-YYYY') adjusted_svc_date,
    (
        SELECT
            territory_short_name
        FROM
            fnd_territories_vl
        WHERE
            territory_code = per.country_of_birth
    ) birth_country,
    hap.attribute1 post_comments,
    (
        SELECT
            MAX(fl.meaning)
        FROM
            fnd_lookup_values_tl fl
        WHERE
            fl.lookup_type = 'FREQUENCY'
            AND   fl.lookup_code (+) = paaf.frequency
            AND   fl.language = userenv('LANG')
    ) asg_frequency,
    (
        SELECT
            MAX(fl.meaning)
        FROM
            fnd_lookup_values_tl fl
        WHERE
            fl.lookup_type = 'NATIONALITY'
            AND   fl.lookup_code (+) = pcz.legislation_code
            AND   fl.language = userenv('LANG')
    ) nationality,
    pay_p.payroll_name,
    hr_org.name department_name,
    paaf.full_part_time part_time_or_full_time,
    manager.display_name manager_name,
paaf.DATE_PROBATION_END as Probation_period_end_date,
(select Distinct PGFT.NAME
from PER_GRADES_F_TL PGFT,
Per_all_assignments_m paam1
where paam1.Assignment_Id =paaf.Assignment_Id
 And paam1.effective_latest_change = 'Y'
 And paam1.primary_flag  = 'Y'
 AND paam1.effective_end_date = paaf.effective_start_date-1
 and paam1.grade_id = PGFT.GRADE_ID
 and PGFT.LANGUAGE ='US'
 and TRUNC(SYSDATE) BETWEEN PGFT.EFFECTIVE_START_DATE AND PGFT.EFFECTIVE_END_DATE
)
as Previous_Grade_name,
    pea.email_address,
--manager.e_address as email_address,
    paaf.ass_attribute_date1 contract_end_date,
   '' as contact_name,

    paaf.frequency,
    paaf.normal_hours working_hours,
    --ple.name legal_employer,
houft.name legal_employer,
---------Raj-----
--dep_h.org_l_4 as Directorate,
      dep_h.org_l_5 as Directorate,
    --dep_h.org_l_6 gparent_organisation_name,
    --dep_h.org_l_7 parent_organisation_name,
      dep_h.org_l_8 as Team,
       ADDR_H.ADDRESS_LINE_1 AS Worker_Address_Line_1,
       ADDR_H.ADDRESS_LINE_2 AS Worker_Address_Line_2,
       ADDR_H.ADDRESS_LINE_3 AS Worker_Address_Line_3,
       ADDR_H.ADDRESS_LINE_4 AS Worker_Address_Line_4,
	   ADDR_H.TOWN_OR_CITY,
	   ADDR_H.REGION_1,
	   ADDR_H.REGION_2,
	   ADDR_H.REGION_3,
  PLDF.LOCATION_NAME,
  SWH.ORG_INFORMATION_NUMBER1 NORMAL_Hours,
 /* (SELECT MAX (PATTERN_NAME)
                      FROM PER_SCHEDULE_ASSIGNMENTS PSA,
                           ZMM_SR_SCHEDULES_VL ZSSVL,
                           MSC_SCHEDULES_V MSV,
                           ZMM_SR_PATTERNS_VL ZSPV
                     WHERE     (PAAF.ASSIGNMENT_ID = PSA.RESOURCE_ID)
                           AND PSA.SCHEDULE_ID = ZSSVL.SCHEDULE_ID
                           AND UPPER (TRIM (PSA.PRIMARY_FLAG)) = 'Y'
                           AND PSA.SCHEDULE_ID = MSV.SCHEDULE_ID
                           AND MSV.PATTERN_ID = ZSPV.PATTERN_ID
      )
                                Pattern_name */

        (  select distinct zsst.schedule_name
    from per_schedule_assignments psa,
     ZMM_SR_SCHEDULES_TL zsst,
     per_all_assignments_m paam
             where 1=1
                  and paam.assignment_id = paaf.assignment_id
                  and psa.schedule_id=zsst.schedule_id
                  and psa.resource_id=paam.assignment_id
                  and psa.resource_type='ASSIGN'
                  and psa.PRIMARY_FLAG='Y'
                  --and paam.assignment_number = 'E100041'
                  and trunc(sysdate) between paam.effective_start_date and paam.effective_end_date
                  and trunc(sysdate) between psa.START_DATE and psa.END_DATE
                  and rownum =1
         ) Pattern_name
		 
		 
  ----------------------End------------

FROM
    per_all_people_f papf,
    per_person_names_f ppnf,
	per_person_types_tl pptt,
    per_all_assignments_m paaf,
    per_persons per,
	per_seniority_dates_f psdf,
    per_addresses_f addr_h,
    per_person_addr_usages_f addr_u_h,
    per_national_identifiers pni,
    hr_organization_units hr_org,
    hr_organization_units bu_unit,
    hr_all_positions hap,
    per_email_addresses pea,
    per_phones phone_h,
    per_grades pg,
    per_jobs pj,
    per_ethnicities pe,
    per_religions pr,
    per_people_legislative_f pplf,
    per_grade_steps_f_vl pgs,
    per_assign_grade_steps_f pagsf,
    per_citizenships pcz,
    per_periods_of_service ppos,
    per_actions_b pab,
    per_action_reasons_vl parb,
    per_action_headers_m pahm,
    per_assign_work_measures_f pawmf,
    per_disabilities_f pdf,
    pay_all_payrolls_f pay_p,
    pay_assigned_payrolls_dn papd,
    pay_rel_groups_dn prgd,
    --per_legal_employers ple,
HR_Organization_units_F_Tl houft,
    (
SELECT
            pasf.manager_type manager_type,
pasf.assignment_id,
            mgrp.display_name,
            asg_act.person_id,
            email1.email_address e_address,
            mgr_papf.person_number m_person_number
        FROM
            per_all_assignments_f asg_act,
            per_assignment_supervisors_f pasf,
            per_person_names_f mgrp,
            per_all_people_f mgr_papf,
            per_email_addresses email1
        WHERE
            nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(pasf.effective_start_date,SYSDATE) AND nvl(pasf.effective_end_date,SYSDATE)
-- AND UPPER (ASG_ACT.ASSIGNMENT_TYPE(+)) IN ('E', 'C')
           -- AND   upper(TRIM(asg_act.primary_flag(+) ) ) = 'Y'
            AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(asg_act.effective_start_date(+),SYSDATE) AND nvl(asg_act.effective_end_date(+),SYSDATE
)
            AND   upper(TRIM(asg_act.effective_latest_change) ) = 'Y'
            AND   pasf.assignment_id (+) = asg_act.assignment_id
            AND   pasf.person_id (+) = asg_act.person_id
            AND   mgr_papf.person_id (+) = pasf.manager_id
            AND   mgrp.person_id (+) = pasf.manager_id
            AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(mgrp.effective_start_date(+),SYSDATE) AND nvl(mgrp.effective_end_date(+),SYSDATE
)
            AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(mgr_papf.effective_start_date(+),SYSDATE) AND nvl(mgr_papf.effective_end_date(+)
,SYSDATE)
            AND   upper(mgrp.name_type) = upper('GLOBAL')
            AND   email1.person_id(+) = mgr_papf.person_id
            AND   email1.email_type(+) = 'W1'
        ) manager,
		
		(SELECT grade_step_start.name    ceiling_step,
                grade.name               grade,
                grade.grade_id,
                ASSIGN.assignment_id
    
         FROM   per_all_assignments_f ASSIGN,
                per_grade_steps_f_vl grade_step_start,
                per_grades_f_vl grade
				
         WHERE  ASSIGN.grade_id = grade.grade_id             
				AND grade.ceiling_step_id = grade_step_start.grade_step_id
				AND Trunc(SYSDATE) BETWEEN Trunc(ASSIGN.effective_start_date) AND Trunc(ASSIGN.effective_end_date)   ) CSTEP,

(select org_level8.name org_l_8,
        org_level7.name org_l_7,
        org_level6.name org_l_6,
        org_level5.name org_l_5,
org_level4.name org_l_4,
org_level3.name org_l_3,
org_level2.name org_l_2,
org_level1.name org_l_1,
org_tree.org_id,
org_tree.tree_code,
    org_level8.organization_id a_l8,
org_level7.organization_id a_l7,
org_level6.organization_id a_l6,
org_level5.organization_id a_l5,
org_level4.organization_id a_l4,
org_level3.organization_id a_l3,
org_level2.organization_id a_l2,
org_level1.organization_id a_l1
from hr_organization_units org_level1,
hr_organization_units org_level2,
hr_organization_units org_level3,
hr_organization_units org_level4,
hr_organization_units org_level5,
hr_organization_units org_level6,
hr_organization_units org_level7,
hr_organization_units org_level8,
(    select pk1_start_value org_id,
tree_code,
tree_version_id,
connect_by_iscycle cycle,
level,
sys_connect_by_path (pk1_start_value, '/') || '/'
orgpath
from (select rownum as rn,
pdtn.pk1_start_value,
pdtn.tree_code,
pdtn.tree_version_id,
pdtn.parent_pk1_value
from per_org_tree_node pdtn, fnd_tree_version ftv
  where 1 = 1 and upper (ftv.status) = 'ACTIVE'
and upper (trim (ftv.tree_structure_code)) =
'PER_ORG_TREE_STRUCTURE'
and ftv.tree_version_id = pdtn.tree_version_id
and pdtn.tree_code = 'PCC_ORG_TREE_v1' -- ONLY ACTIVE TREE REQUIRED
 )
 start with pk1_start_value = 1          --ACTIVE ORG TREE ID
 connect by nocycle prior pk1_start_value = parent_pk1_value) org_tree
  where substr (org_tree.orgpath, 2, instr (org_tree.orgpath,
'/',
1,
2)
 - 2) =
org_level1.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level1.
  date_from(+)
 and org_level1.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 2)
  + 1, instr (org_tree.orgpath,
  '/',
  1,
  3)
- 4) =
org_level2.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level2.
  date_from(+)
 and org_level2.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 3)
  + 1,   instr (org_tree.orgpath,
'/',
1,
4)
- instr (org_tree.orgpath,
'/',
1,
3)
+ 1
- 2) =
org_level3.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level3.
  date_from(+)
 and org_level3.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 4)
  + 1,   instr (org_tree.orgpath,
'/',
1,
5)
- instr (org_tree.orgpath,
'/',
1,
4)
+ 1
- 2) =
org_level4.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level4.
  date_from(+)
 and org_level4.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 5)
  + 1,   instr (org_tree.orgpath,
'/',
1,
6)
- instr (org_tree.orgpath,
'/',
1,
5)
+ 1
- 2) =
org_level5.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level5.
  date_from(+)
 and org_level5.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 6)
  + 1,   instr (org_tree.orgpath,
'/',
1,
7)
- instr (org_tree.orgpath,
'/',
1,
6)
+ 1
- 2) =
org_level6.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level6.
  date_from(+)
 and org_level6.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 7)
  + 1,   instr (org_tree.orgpath,
'/',
1,
8)
- instr (org_tree.orgpath,
'/',
1,
7)
+ 1
- 2) =
org_level7.organization_id(+) --LEVEL MAY NOT BE THERE IN TREE
and nvl (:p_effective_date, trunc (sysdate)) between org_level7.
  date_from(+)
 and org_level7.
  date_to(+) --date may be blank
and substr (org_tree.orgpath, instr (org_tree.orgpath,
 '/',
 1,
 8)
  + 1,   instr (org_tree.orgpath,
'/',
1,
9)
- instr (org_tree.orgpath,
'/',
1,
8)
+ 1
- 2) =
org_level8.organization_id(+)) dep_h,

------ Raj Added ----
PER_LOCATION_DETAILS_F_VL PLDF,
HR_ORGANIZATION_INFORMATION_F SWH
---------------END----  
 
WHERE
    ppnf.person_id = papf.person_id
	AND   papf.person_id = psdf.person_id
    AND   per.person_id (+) = papf.person_id
    AND   paaf.person_id = papf.person_id
    AND   upper(TRIM(paaf.effective_latest_change) ) = 'Y'
    AND   upper(TRIM(paaf.assignment_type(+) ) ) = 'E'   --as per Ebiz code
-- and upper (paaf.assignment_status_type) in ('ACTIVE',) --as per Ebiz code
    AND   upper(TRIM(ppnf.name_type) ) = 'GLOBAL'
	AND   pptt.person_type_id = paaf.person_type_id
    AND   addr_u_h.person_id (+) = papf.person_id
    AND   upper(addr_u_h.address_type(+) ) = 'HOME'
    AND   pni.person_id (+) = papf.person_id
    AND   pni.national_identifier_id (+) = papf.primary_nid_id
    AND   hr_org.organization_id (+) = paaf.organization_id
    AND   pg.grade_id (+) = paaf.grade_id
	AND   pg.grade_id = CSTEP.grade_id
    AND   hap.position_id (+) = paaf.position_id
    AND   pea.person_id (+) = papf.person_id
    AND   pea.email_address_id (+) = papf.primary_email_id
    AND   manager.person_id (+) = papf.person_id
    AND   manager.assignment_id(+) = paaf.assignment_id
    AND   phone_h.person_id (+) = papf.person_id
    AND   phone_h.phone_id (+) = papf.primary_phone_id
    AND   upper(TRIM(phone_h.phone_type(+) ) ) = 'HM'
    AND   pj.job_id (+) = paaf.job_id
    AND   pdf.person_id (+) = papf.person_id
    AND   addr_h.address_id (+) = addr_u_h.address_id
    AND   pplf.person_id (+) = papf.person_id
    AND   pe.person_id (+) = papf.person_id
    AND   pr.person_id (+) = papf.person_id
    AND   ppos.person_id (+) = paaf.person_id
    AND   ppos.period_of_service_id (+) = paaf.period_of_service_id
    AND   paaf.action_code = pab.action_code (+)
    AND   pab.action_id = pahm.action_id (+)
    AND   pahm.action_reason_id = parb.action_reason_id (+)
    AND   pcz.person_id (+) = papf.person_id
    AND   paaf.assignment_id = pagsf.assignment_id (+)
    AND   pagsf.grade_step_id = pgs.grade_step_id (+)
    AND   pgs.grade_id (+) = pg.grade_id     --may not have step in grade_id
    AND   bu_unit.organization_id = paaf.business_unit_id
    AND   upper(TRIM(pawmf.unit(+) ) ) = 'FTE' --required to fetch the employee FTE Value
    AND   papd.payroll_id = pay_p.payroll_id (+)
    AND   prgd.parent_rel_group_id = papd.payroll_term_id (+)
    AND   prgd.assignment_id (+) = paaf.assignment_id
    --AND   paaf.legal_entity_id  = ple.legal_entity_id (+)
AND   paaf.legal_entity_id  = houft.organization_id (+)
AND   houft.Language = USERENV('LANG')
    AND   pawmf.assignment_id (+) = paaf.assignment_id
--------Raj Added------
and paaf.organization_id = dep_h.org_id(+)
AND PLDF.LOCATION_ID(+) = paaf.LOCATION_ID
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(PLDF.effective_start_date(+) ) AND trunc(PLDF.effective_end_date(+))
AND SWH.ORG_INFORMATION_CONTEXT='PER_WORK_DAY_INFO'
AND SWH.organization_id=1
---------End------------------
    --AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(ple.effective_start_date(+) ) AND trunc(ple.effective_end_date(+) )
AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(houft.effective_start_date(+) ) AND trunc(houft.effective_end_date(+))
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(ppnf.effective_start_date) AND trunc(ppnf.effective_end_date)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(papf.effective_start_date) AND trunc(papf.effective_end_date)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(paaf.effective_start_date) AND trunc(paaf.effective_end_date)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(addr_u_h.effective_start_date(+) ) AND trunc(addr_u_h.effective_end_date(+) )
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(papd.start_date(+),SYSDATE) AND nvl(papd.end_date(+),SYSDATE)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(pawmf.effective_start_date(+),SYSDATE) AND nvl(pawmf.effective_end_date(+),SYSDATE)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(pay_p.effective_start_date(+),SYSDATE) AND nvl(pay_p.effective_end_date(+),SYSDATE)
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(pgs.effective_start_date(+) ) AND trunc(pgs.effective_end_date(+) )
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(pplf.effective_start_date(+) ) AND trunc(pplf.effective_end_date(+) )
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN trunc(addr_h.effective_start_date(+) ) AND trunc(addr_h.effective_end_date(+) )
    AND   nvl(:p_effective_date,trunc(SYSDATE) ) BETWEEN nvl(pdf.effective_start_date(+),SYSDATE) AND nvl(pdf.effective_end_date(+),SYSDATE)
    AND   paaf.assignment_number = nvl(:p_assignment_number,paaf.assignment_number)
    AND   papf.person_id = nvl(:p_number,papf.person_id)
ORDER BY
    papf.person_number,
    ( ppnf.last_name
    || ', '
    || ppnf.first_name )