select hapf.name HR_POSITION_NAME,
ppnf.TITLE HR_TITLE,
ppnf.FIRST_NAME HR_FIRSTNAME,
ppnf.LAST_NAME HR_LASTNAME,
pp.phone_number HR_CONTACT_NUMBER

from per_users pu,
per_all_assignments_f paaf,
hr_all_positions_f_tl hapf,
per_person_names_f ppnf,
per_phones pp

where UPPER(pu.username)=UPPER(:xdo_user_name)
AND pu.person_id = paaf.person_id
AND paaf.position_id = hapf.position_id
AND pu.person_id = ppnf.person_id
AND pu.person_id = pp.person_id
AND UPPER(TRIM(ppnf.name_type)) = UPPER(TRIM('GLOBAL'))						-- Language
AND UPPER (paaf.primary_flag) = UPPER ('Y')							-- for primary assignment
AND UPPER (paaf.effective_latest_change) = UPPER ('Y')			-- for latest change
AND TRUNC (SYSDATE) BETWEEN TRUNC (paaf.effective_start_date) AND TRUNC (paaf.effective_end_date)
AND TRUNC (SYSDATE) BETWEEN TRUNC (hapf.effective_start_date) AND TRUNC (hapf.effective_end_date)
AND TRUNC (SYSDATE) BETWEEN TRUNC (ppnf.effective_start_date) AND TRUNC (ppnf.effective_end_date)
AND paaf.assignment_status_type = 'ACTIVE'