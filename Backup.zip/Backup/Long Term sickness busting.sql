SELECT
    paaf.assignment_id key,
    'Output_wf' template,
    'RTF' AS template_format, -- template format
    'HTML' AS output_format, -- output format pdf rtf text etc..
    'EMAIL' AS del_channel, -- delivery channel name email,fax,print etc..
	--  mgr_pea.email_address parameter1, -- to mail address
    'abid.nana@walsall.gov.uk' parameter1, -- to mail address
    'Joanna.Nicholls@walsall.gov.uk' parameter2,-- CC mail address
    'hrdoperationalservices@auto.walsall.gov.uk' AS parameter3,  -- from mail address
    'Long Term Sickness Stage 1 Case Review Required' AS parameter4, -- subject
    ' ' AS parameter5, -- message body
    'false' AS parameter6, -- attachment true/false value
    ' ' AS parameter7 -- reply-to mail address
FROM
    per_all_assignments_f paaf,
    per_assignment_supervisors_f pasf,
    per_person_names_f mgr_ppnf,
    per_email_addresses mgr_pea,
    per_email_addresses emp_pea,
    hr_documents_of_record dor,
    hr_document_types_tl dor_type
WHERE
    paaf.assignment_id = pasf.assignment_id (+)
    AND   paaf.person_id = pasf.person_id (+)
    AND   pasf.manager_id = mgr_ppnf.person_id (+)
    AND   mgr_pea.person_id (+) = mgr_ppnf.person_id
    AND   emp_pea.person_id (+) = paaf.person_id
    AND   upper(TRIM(mgr_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(emp_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(mgr_ppnf.name_type(+) ) ) = upper(TRIM('GLOBAL') ) -- english name
    AND   upper(TRIM(paaf.effective_latest_change(+) ) ) = upper(TRIM('Y') ) -- latest assignment
    AND   upper(TRIM(pasf.manager_type(+) ) ) = ( 'LINE_MANAGER' )-- only line manager
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_pea.date_from(+),SYSDATE) ) AND trunc(nvl(mgr_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(emp_pea.date_from(+),SYSDATE) ) AND trunc(nvl(emp_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(pasf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(pasf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(paaf.effective_start_date) AND trunc(paaf.effective_end_date)
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_ppnf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(mgr_ppnf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   paaf.person_id = dor.person_id (+)
    AND   dor.document_type_id = dor_type.document_type_id (+)
    AND   dor_type.language = userenv('LANG')
    AND   dor_type.source_lang = userenv('LANG')
    AND   dor.dei_attribute_date2 IS NULL
    AND   upper(TRIM(dor_type.document_type) ) = 'LONG TERM SICKNESS'
    AND   paaf.assignment_type = 'E'
	 AND   paaf.assignment_number = dor.dei_attribute4
    and COALESCE(dor.dei_attribute_date14
		,dor.dei_attribute_date13
		,dor.dei_attribute_date12
		,dor.dei_attribute_date11
		,dor.dei_attribute_date10
		,dor.dei_attribute_date9
		,dor.dei_attribute_date8
		,dor.dei_attribute_date7
		,dor.dei_attribute_date6
		,dor.dei_attribute_date5
		,dor.dei_attribute_date4
		,dor.dei_attribute_date3) + 42 = trunc(SYSDATE)
UNION ALL
SELECT
    paaf.assignment_id key,
    'Output_s1' template,
    'RTF' AS template_format, -- template format
    'HTML' AS output_format, -- output format pdf rtf text etc..
    'EMAIL' AS del_channel, -- delivery channel name email,fax,print etc..
   --  mgr_pea.email_address parameter1, -- to mail address
    'abid.nana@walsall.gov.uk' parameter1, -- to mail address
    'Joanna.Nicholls@walsall.gov.uk' parameter2,-- CC mail address
    'hrdoperationalservices@auto.walsall.gov.uk' AS parameter3,  -- from mail address
    'Long Term Sickness Stage 2 Case Review Required' AS parameter4, -- subject
    ' ' AS parameter5, -- message body
    'false' AS parameter6, -- attachment true/false value
    ' ' AS parameter7 -- reply-to mail address
FROM
    per_all_assignments_f paaf,
    per_assignment_supervisors_f pasf,
    per_person_names_f mgr_ppnf,
    per_email_addresses mgr_pea,
    per_email_addresses emp_pea,
    hr_documents_of_record dor,
    hr_document_types_tl dor_type
WHERE
    paaf.assignment_id = pasf.assignment_id (+)
    AND   paaf.person_id = pasf.person_id (+)
    AND   pasf.manager_id = mgr_ppnf.person_id (+)
    AND   mgr_pea.person_id (+) = mgr_ppnf.person_id
    AND   emp_pea.person_id (+) = paaf.person_id
    AND   upper(TRIM(mgr_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(emp_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(mgr_ppnf.name_type(+) ) ) = upper(TRIM('GLOBAL') ) -- english name
    AND   upper(TRIM(paaf.effective_latest_change(+) ) ) = upper(TRIM('Y') ) -- latest assignment
    AND   upper(TRIM(pasf.manager_type(+) ) ) = ( 'LINE_MANAGER' )-- only line manager
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_pea.date_from(+),SYSDATE) ) AND trunc(nvl(mgr_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(emp_pea.date_from(+),SYSDATE) ) AND trunc(nvl(emp_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(pasf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(pasf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(paaf.effective_start_date) AND trunc(paaf.effective_end_date)
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_ppnf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(mgr_ppnf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   paaf.person_id = dor.person_id (+)
    AND   paaf.assignment_type = 'E'
    AND   dor.document_type_id = dor_type.document_type_id (+)
    AND   dor_type.language = userenv('LANG')
    AND   dor_type.source_lang = userenv('LANG')
    AND   dor.dei_attribute_date2 IS NULL
    AND   upper(TRIM(dor_type.document_type) ) = 'LONG TERM SICKNESS'
   AND   dor.DEI_ATTRIBUTE_DATE15 + 42 = trunc(SYSDATE)
    AND   paaf.assignment_number = dor.dei_attribute4
UNION ALL
SELECT
    paaf.assignment_id key,
    'Output_s2' template,
    'RTF' AS template_format, -- template format
    'HTML' AS output_format, -- output format pdf rtf text etc..
    'EMAIL' AS del_channel, -- delivery channel name email,fax,print etc..
    --  mgr_pea.email_address parameter1, -- to mail address
    'abid.nana@walsall.gov.uk' parameter1, -- to mail address
    'Joanna.Nicholls@walsall.gov.uk' parameter2,-- CC mail address
    'hrdoperationalservices@auto.walsall.gov.uk' AS parameter3,  -- from mail address
    'Long Term Sickness Stage 3 Case Review Required' AS parameter4, -- subject
    ' ' AS parameter5, -- message body
    'false' AS parameter6, -- attachment true/false value
    ' ' AS parameter7 -- reply-to mail address
FROM
    per_all_assignments_f paaf,
    per_assignment_supervisors_f pasf,
    per_assignment_supervisors_f pasf_2,
    per_person_names_f mgr_ppnf,
    per_email_addresses mgr_pea,
    per_email_addresses mgr_pea_2,
    per_email_addresses emp_pea,
    hr_documents_of_record dor,
    hr_document_types_tl dor_type
WHERE
    paaf.assignment_id = pasf.assignment_id (+)
    AND   paaf.person_id = pasf.person_id (+)
    AND   pasf.manager_id = mgr_ppnf.person_id (+)
    AND   mgr_pea.person_id (+) = mgr_ppnf.person_id
    AND   emp_pea.person_id (+) = paaf.person_id
    AND   upper(TRIM(mgr_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(emp_pea.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   upper(TRIM(mgr_ppnf.name_type(+) ) ) = upper(TRIM('GLOBAL') ) -- english name
    AND   upper(TRIM(paaf.effective_latest_change(+) ) ) = upper(TRIM('Y') ) -- latest assignment
    AND   upper(TRIM(pasf.manager_type(+) ) ) = ( 'LINE_MANAGER' )-- only line manager
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_pea.date_from(+),SYSDATE) ) AND trunc(nvl(mgr_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(emp_pea.date_from(+),SYSDATE) ) AND trunc(nvl(emp_pea.date_to(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(pasf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(pasf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   trunc(SYSDATE) BETWEEN trunc(paaf.effective_start_date) AND trunc(paaf.effective_end_date)
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_ppnf.effective_start_date(+),SYSDATE) ) AND trunc(nvl(mgr_ppnf.effective_end_date(+),SYSDATE) ) -- date may be null
    AND   paaf.person_id = dor.person_id (+)
    AND   paaf.assignment_type = 'E'
    AND   dor.document_type_id = dor_type.document_type_id (+)
    AND   dor_type.language = userenv('LANG')
    AND   dor_type.source_lang = userenv('LANG')
    AND   dor.dei_attribute_date2 IS NULL
    AND   upper(TRIM(dor_type.document_type) ) = 'LONG TERM SICKNESS'


    AND   pasf.manager_id = pasf_2.person_id (+)
    AND   pasf_2.manager_id = mgr_pea_2.person_id (+)
    AND   upper(TRIM(pasf_2.manager_type(+) ) ) = ( 'LINE_MANAGER' )-- only line manager
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(pasf_2.effective_start_date(+),SYSDATE) ) AND trunc(nvl(pasf_2.effective_end_date(+),SYSDATE) )
    AND   upper(TRIM(mgr_pea_2.email_type(+) ) ) = upper(TRIM('W1') ) --work required
    AND   trunc(SYSDATE) BETWEEN trunc(nvl(mgr_pea_2.date_from(+),SYSDATE) ) AND trunc(nvl(mgr_pea_2.date_to(+),SYSDATE) ) -- date may be null
   AND   to_DATE(dor.DEI_ATTRIBUTE18,'DD-MM-YYYY') + 42 = trunc(SYSDATE)
    AND   paaf.assignment_number = dor.dei_attribute4