Fast Formula

 Types of FF
 Default define
 BDI Types 2 types
 single row dbi
 multi row dbi

XX EBS PHONE H1

default_data_value for PER_EXT_PHONE_TYPE is 'null'
default_data_value for PER_EXT_PHONE_NUMBER is 'null'
default_data_value for PER_EXT_PHONE_AREA_CODE is 'null'


  I = 1
  WHILE PER_EXT_PHONE_TYPE.EXISTS(I) LOOP
  (
    phone_type = PER_EXT_PHONE_TYPE[I]
    rule_value = PER_EXT_PHONE_AREA_CODE[I]||PER_EXT_PHONE_NUMBER[I]
 
    if (phone_type= 'H1') then
    (
       return rule_value
    )
    I = I + 1
  )


  /
  
PER_EXT_PHONE_TYPE[1] = 'H1'
PER_EXT_PHONE_TYPE[2] = 'WP'
PER_EXT_PHONE_TYPE[3] = 'WF'
PER_EXT_PHONE_TYPE[4] = 'WM'

PER_EXT_PHONE_NUMBER[1] = '286-9992	'
PER_EXT_PHONE_NUMBER[2] = '541-3790'
PER_EXT_PHONE_NUMBER[3] = '357-3878'
PER_EXT_PHONE_NUMBER[4] = '699-1479'

PER_EXT_CONT_AREA_CODE[1] = '154'

phone_type = H1

 rule_value = 154286-9992

/

PERSON NUMBER
PERSON LEGAL EMPLOYER
MANAGER NUMBER
MANAGER LEGAL EMPLOYER

l_effective_date = 01-01-2017


DEFAULT FOR PER_ASG_START_DATE IS '1951/01/01 00:00:00'(date)
DEFAULT FOR PER_LEGAL_EMPLOYER_LEGAL_ENTITY_IDENTIFIER IS 'A'
DEFAULT_DATA_VALUE FOR PER_EXT_ASG_REPORTEE_MGR_PERSON_ID IS 0
DEFAULT FOR PER_ASG_MGR_MANAGER_ID IS -1
DEFAULT FOR PER_ASG_MGR_MANAGER_ASG_ID IS 0
DEFAULT FOR PER_ASG_ORG_LEGAL_EMPLOYER_NAME IS 'X'

l_effective_date = GET_CONTEXT(EFFECTIVE_DATE,'0001/01/01 00:00:00'(date))


l_legal_emp_id = PER_ASG_MGR_MANAGER_ID
ld_date = PER_ASG_START_DATE
ln_assignment_id = GET_CONTEXT(HR_ASSIGNMENT_ID,-1)

    CHANGE_CONTEXTS(EFFECTIVE_DATE = l_effective_date ,HR_ASSIGNMENT_ID =ln_assignment_id)
              (
                   ln_mgr_assignment_id = PER_ASG_MGR_MANAGER_ASG_ID
              )


    CHANGE_CONTEXTS(EFFECTIVE_DATE = l_effective_date ,HR_ASSIGNMENT_ID =ln_mgr_assignment_id)
              (
                   lv_mgr_legal_employer = PER_ASG_ORG_LEGAL_EMPLOYER_NAME
              )
              
            RULE_VALUE =  lv_mgr_legal_employer 
            
RETURN RULE_VALUE

