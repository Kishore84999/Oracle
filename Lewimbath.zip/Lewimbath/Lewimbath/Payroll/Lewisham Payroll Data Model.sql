SELECT * FROM 
(
(select
person_id,
end_date,
start_date,
(case when floor(sum(days_worked))>TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99') then TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99') else floor(sum(days_worked)) end) d_worked,
round(sum(per),2) per,
round(sum(pt_salary),2) kk,
sum(tpa) tp,
SUM(PEN_PAY) PEN_PAY,
(100/COUNT(ASSIGNMENT_ID)) avg1,
(case when sum(per)=0
then  /* (case when CEIL(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2))-round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2)<.50 then CEIL(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2)) 
			else /* floor(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2)) 	
			
			end) */
			(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2))
else 
/*  (case when CEIL(round( (sum(pt_salary)/sum(per)),2))-round( (sum(pt_salary)/sum(per)),2)<.50 then CEIL(round( (sum(pt_salary)/sum(per)),2))
			else floor(round( (sum(pt_salary)/sum(per)),2))	end)  */
			round( (sum(pt_salary)/sum(per)),2)
			
end) fte_salary,
(case when floor(sum(days_worked))>TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99') then TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99') else floor(sum(days_worked)) end) d_exc

from
(select 
person_id,
end_date,
start_date,
assignment_id,
assignment_number,
(pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99')) PEN_PAY,
tpa,
end_date-start_date+1 t_m_days,
(case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end) days_worked,
((case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end)/(end_date-start_date+1)) per,
(tpa*(((case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end)/(end_date-start_date+1))*100)/100) pt_salary

from

(
	SELECT
     	 paaf.person_id,
			CASE WHEN TO_CHAR(PTP.START_DATE,'MM')='04' THEN PTP.START_DATE+5 ELSE PTP.START_DATE END START_DATE,
			CASE WHEN TO_CHAR(PTP.START_DATE,'MM')='04' THEN PTP.END_DATE ELSE PTP.END_DATE END END_DATE,
			PAAF.ASSIGNMENT_ID,
			paaf.assignment_number,
			SUM(CASE WHEN UPPER (TRIM (BAL1.BALANCE_NAME)) = upper(trim('Teachers Pensionable Pay Employee') ) THEN  BAL1.VALUE1 END) PEN_PAY,
			SUM(CASE WHEN UPPER (TRIM (BAL1.BALANCE_NAME)) = upper(trim('TPA Salary') ) THEN  BAL1.VALUE1 END) TPA			
			
        FROM
            pay_payroll_rel_actions pra,
            pay_payroll_actions ppa,
            pay_payroll_assignments ppa1, 
			PAY_DEFINED_BALANCES PDB,
			PAY_DIMENSION_USAGES PDU,
			pay_time_periods ptp,
			PER_PERIODS_OF_SERVICE PPOS,
			per_all_assignments_f paaf,
			TABLE ( pay_balance_view_pkg.get_balance_matrix( p_balance_group_usage_id => ( SELECT  bal_grp_usage_id
                                                                                  FROM pay_bal_grp_usages
                                                                                WHERE UPPER(base_group_usage_name) = UPPER('MDC_GROUP'))
                                                        ,p_payroll_rel_action_id  => pra.payroll_rel_action_id
                                                        ,p_payroll_assignment_id => ppa1.payroll_assignment_id)) bal1
		WHERE  pra.payroll_relationship_id = PPA1.payroll_relationship_id
            AND   EXISTS (
                SELECT
                    1
                FROM
                    pay_run_results prr
                WHERE
                    prr.payroll_rel_action_id = pra.payroll_rel_action_id
            )
            AND   ppa.payroll_action_id = pra.payroll_action_id
            AND   upper(TRIM(ppa.action_type) ) IN (
                upper(TRIM('I') ),
                upper(TRIM('R') ),
                upper(TRIM('Q') )
            ) -- Balance initialization 
			and bal1.PAYROLL_REL_ACTION_ID = pra.payroll_rel_action_id
			
            AND   pra.retro_component_id IS NULL
			AND PDB.DEFINED_BALANCE_ID=	BAL1.DEFBAL_ID1
			AND PDB.BALANCE_DIMENSION_ID=PDU.BALANCE_DIMENSION_ID
			AND PDU.LEGISLATION_CODE='GB'
			 AND   ppa.payroll_id = ptp.payroll_id
    AND   ptp.time_period_id = ppa.earn_time_period_id
    AND   ptp.period_category = 'E'
    AND   trunc( ppa.date_earned ) BETWEEN trunc( ptp.start_date ) AND trunc( ptp.end_date )
		AND PPOS.PERSON_ID=ppa1.PERSON_ID
	 AND   paaf.person_id = ppa1.person_id
    AND   paaf.assignment_id = ppa1.hr_assignment_id
    AND   ( ppa.date_earned ) BETWEEN ( paaf.effective_start_date ) AND ( paaf.effective_end_date )
    AND   upper(TRIM(paaf.assignment_type) ) = upper(TRIM('e') )
    AND   upper(TRIM(paaf.effective_latest_change) ) = upper(TRIM('y') )
 AND PPOS.PERSON_ID=PAAF.PERSON_ID
	AND PPOS.PERIOD_OF_SERVICE_ID=PAAF.PERIOD_OF_SERVICE_ID
	--AND (PPOS.DATE_START)=(SELECT MAX(PPOS1.DATE_START) FROM PER_PERIODS_OF_SERVICE PPOS1 WHERE PPOS.PERSON_ID=PPOS1.PERSON_ID)
	/* and (paaf.assignment_number like '%511315%'
	or paaf.assignment_number like '%006786%') */
	AND (PPOS.DATE_START)=(SELECT MAX(PPOS1.DATE_START) FROM PER_PERIODS_OF_SERVICE PPOS1 WHERE PPOS.PERSON_ID=PPOS1.PERSON_ID)
group by    paaf.person_id,
			ptp.end_date,
			ptp.START_DATE,
			PAAF.ASSIGNMENT_ID,
			paaf.assignment_number
			))
group by person_id,
end_date,
start_date,
t_m_days
)
UNION
(select
person_id,
end_date,
start_date,
floor(sum(days_worked)) d_worked,
round(sum(per),2) per,
round(sum(pt_salary),2) kk,
sum(tpa) tp,
SUM(PEN_PAY) PEN_PAY,
(100/COUNT(ASSIGNMENT_ID)) avg1,
(case when sum(per)=0
then  (case when CEIL(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2))-round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2)<.50 then CEIL(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2))
			else floor(round( (sum(tpa)/(100/COUNT(ASSIGNMENT_ID))),2))	end) 
else 
 (case when CEIL(round( (sum(pt_salary)/sum(per)),2))-round( (sum(pt_salary)/sum(per)),2)<.50 then CEIL(round( (sum(pt_salary)/sum(per)),2))
			else floor(round( (sum(pt_salary)/sum(per)),2))	end) 
			
end) fte_salary,
floor(sum(days_worked))  d_exc

from
(select 
person_id,
end_date,
start_date,
assignment_id,
assignment_number,
(pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99')) PEN_PAY,
tpa,
end_date-start_date+1 t_m_days,
(case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end) days_worked,
((case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end)/(end_date-start_date+1)) per,
(tpa*(((case when tpa<>0 then ((pen_pay*(end_date-start_date+1)/TO_NUMBER(TO_CHAR(LAST_DAY(END_DATE),'DD'),'99'))/tpa)*365 end)/(end_date-start_date+1))*100)/100) pt_salary

from

(SELECT
     	 paaf.person_id,
			CASE WHEN TO_CHAR(PTP.START_DATE,'MM')='04' THEN PTP.START_DATE ELSE PTP.START_DATE END START_DATE,
			CASE WHEN TO_CHAR(PTP.START_DATE,'MM')='04' THEN PTP.START_DATE+4 ELSE PTP.END_DATE END END_DATE,
			PAAF.ASSIGNMENT_ID,
			paaf.assignment_number,
			SUM(CASE WHEN UPPER (TRIM (BAL1.BALANCE_NAME)) = upper(trim('Teachers Pensionable Pay Employee') ) THEN BAL1.VALUE1 END) PEN_PAY,
			SUM(CASE WHEN UPPER (TRIM (BAL1.BALANCE_NAME)) = upper(trim('TPA Salary') ) THEN BAL1.VALUE1 END) TPA
FROM
    pay_payroll_rel_actions pra,
            pay_payroll_actions ppa,
            pay_payroll_assignments ppa1, 
			PAY_DEFINED_BALANCES PDB,
			PAY_DIMENSION_USAGES PDU,
			pay_time_periods ptp,
			PER_PERIODS_OF_SERVICE PPOS,
			per_all_assignments_f paaf,
			TABLE ( pay_balance_view_pkg.get_balance_matrix( p_balance_group_usage_id => ( SELECT  bal_grp_usage_id
                                                                                  FROM pay_bal_grp_usages
                                                                                WHERE UPPER(base_group_usage_name) = UPPER('MDC_GROUP'))
                                                        ,p_payroll_rel_action_id  => pra.payroll_rel_action_id
                                                        ,p_payroll_assignment_id => ppa1.payroll_assignment_id)) bal1
		WHERE  pra.payroll_relationship_id = PPA1.payroll_relationship_id
            AND   EXISTS (
                SELECT
                    1
                FROM
                    pay_run_results prr
                WHERE
                    prr.payroll_rel_action_id = pra.payroll_rel_action_id
            )
            AND   ppa.payroll_action_id = pra.payroll_action_id
            AND   upper(TRIM(ppa.action_type) ) IN (
                upper(TRIM('I') ),
                upper(TRIM('R') ),
                upper(TRIM('Q') )
            ) -- Balance initialization 
			and bal1.PAYROLL_REL_ACTION_ID = pra.payroll_rel_action_id
			
            AND   pra.retro_component_id IS NULL
			AND PDB.DEFINED_BALANCE_ID=	BAL1.DEFBAL_ID1
			AND PDB.BALANCE_DIMENSION_ID=PDU.BALANCE_DIMENSION_ID
			AND PDU.LEGISLATION_CODE='GB'
			 AND   ppa.payroll_id = ptp.payroll_id
    AND   ptp.time_period_id = ppa.earn_time_period_id
    AND   ptp.period_category = 'E'
    AND   trunc( ppa.date_earned ) BETWEEN trunc( ptp.start_date ) AND trunc( ptp.end_date )
		AND PPOS.PERSON_ID=ppa1.PERSON_ID
	 AND   paaf.person_id = ppa1.person_id
    AND   paaf.assignment_id = ppa1.hr_assignment_id
    AND   ( ppa.date_earned ) BETWEEN ( paaf.effective_start_date ) AND ( paaf.effective_end_date )
    AND   upper(TRIM(paaf.assignment_type) ) = upper(TRIM('e') )
    AND   upper(TRIM(paaf.effective_latest_change) ) = upper(TRIM('y') )
 AND PPOS.PERSON_ID=PAAF.PERSON_ID
	AND PPOS.PERIOD_OF_SERVICE_ID=PAAF.PERIOD_OF_SERVICE_ID
	--AND (PPOS.DATE_START)=(SELECT MAX(PPOS1.DATE_START) FROM PER_PERIODS_OF_SERVICE PPOS1 WHERE PPOS.PERSON_ID=PPOS1.PERSON_ID)
	/* and (paaf.assignment_number like '%511315%'
	or paaf.assignment_number like '%006786%') */
	AND (PPOS.DATE_START)=(SELECT MAX(PPOS1.DATE_START) FROM PER_PERIODS_OF_SERVICE PPOS1 WHERE PPOS.PERSON_ID=PPOS1.PERSON_ID)
		and TO_CHAR(PTP.START_DATE,'MM')='04' 
		
GROUP BY  paaf.person_id,
			ptp.end_date,
			ptp.START_DATE,
			PAAF.ASSIGNMENT_ID,
			paaf.assignment_number
))
group by person_id,
end_date,
start_date,
t_m_days
)
)