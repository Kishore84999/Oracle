SELECT ppnf.order_name Employee_Name
      ,papf.person_number Employee_Number
,PPOS.ACTUAL_TERMINATION_DATE 
 ,(SELECT 
	--T.DESCRIPTION,
	T.ACTION_NAME
FROM PER_ACTIONS_B B,
	PER_ACTIONS_TL T,
	PER_ACTION_OCCURRENCES   REASON
WHERE B.ACTION_ID = T.ACTION_ID
AND B.ACTION_ID =REASON.ACTION_ID
AND REASON.ACTION_OCCURRENCE_ID =ppos.ACTION_OCCURRENCE_ID
) ACTION
 ,ppos.ACTION_OCCURRENCE_ID
 ,(select ACTION_REASON 
            from PER_ACTION_REASONS_TL part,
                 PER_ACTION_OCCURRENCES  pao
            where 1=1
            and part.ACTION_REASON_ID=pao.ACTION_REASON_ID
            and pao.ACTION_OCCURRENCE_ID=ppos.ACTION_OCCURRENCE_ID
            and rownum<=1)REASON  
, Line_Manager.NAME MGR_NAME
,Line_Manager.PERSON_NUMBER MGR_NUMBER
,COMMENTS 
,WORKER_COMMENTS  
FROM PER_ALL_ASSIGNMENTS_F PAAF   
    ,per_periods_of_service ppos
    ,per_persons pp
    ,per_all_people_f papf
    ,per_person_names_f ppnf
    ,PER_PERSON_TYPES_VL ppt
	,(select paaf.ASSIGNMENT_ID,papf2.person_number
, ppnf2.display_name NAME
from per_assignment_supervisors_f pasf
	                            ,per_all_people_f papf2
	                            ,per_person_names_f ppnf2
								 ,per_all_assignments_m paaf
							where 1=1
							--and paaf.ASSIGNMENT_ID=300000002759253
							and paaf.ASSIGNMENT_ID=pasf.ASSIGNMENT_ID
                            and MANAGER_TYPE='LINE_MANAGER'

                            and papf2.person_id=pasf.MANAGER_ID
                            and ppnf2.person_id=pasf.MANAGER_ID
                            AND ppnf2.name_type = 'GLOBAL' 
							AND paaf.primary_flag = 'Y'
							AND TRUNC (sysdate) BETWEEN papf2.effective_start_date
                                               AND papf2.effective_end_date
                            AND TRUNC (sysdate) BETWEEN ppnf2.effective_start_date
                                                AND ppnf2.effective_end_date
                            AND TRUNC (sysdate) BETWEEN pasf.effective_start_date
                                                 AND pasf.effective_end_date
							AND TRUNC (sysdate) BETWEEN paaf.effective_start_date
                                                  AND paaf.effective_end_date)
												  Line_Manager
WHERE 1=1

AND   PAAF.period_of_service_id = PPOS.period_of_service_id
AND   PAAF.person_id = pp.person_id

AND   PAAF.person_id = papf.person_id

AND   TRUNC(:P_FROM_DATE) BETWEEN papf.effective_start_date AND papf.effective_end_date

AND   PAAF.person_id = ppnf.person_id
AND   TRUNC(:P_FROM_DATE) BETWEEN ppnf.effective_start_date AND ppnf.effective_end_date
AND   ppnf.name_type = 'GLOBAL'

AND   paaf.person_type_id = ppt.person_type_id
AND   ppos.primary_flag = 'Y'

AND   PAAF.ASSIGNMENT_TYPE in ('E')
AND   PAAF.primary_assignment_flag = 'Y'
AND  Line_Manager.ASSIGNMENT_ID(+)=paaf.ASSIGNMENT_ID 
and   TRUNC(:P_FROM_DATE) between paaf.effective_start_date AND paaf.effective_end_date
AND  --(PPOS.ACTUAL_TERMINATION_DATE IS NOT NULL
  trunc(PPOS.ACTUAL_TERMINATION_DATE) BETWEEN  TRUNC(:P_FROM_DATE) AND TRUNC(:P_TO_DATE)
 -- AND PERSON_NUMBER='901568'